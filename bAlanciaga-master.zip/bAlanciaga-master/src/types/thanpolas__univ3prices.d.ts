declare module '@thanpolas/univ3prices' {
    const value: any; // Use 'any' type or define specific types if known
    export default value;
}
