import { Wallet } from '@dynamic-labs/sdk-react-core';

export type DynamicWallet = Wallet<any>; 