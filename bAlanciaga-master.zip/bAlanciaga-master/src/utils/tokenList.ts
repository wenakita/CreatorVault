import { TokenListType } from '../types/token';

export const TokenList: TokenListType = {
  tokens: [
    // Arbitrum Tokens
    {
      chainId: 42161,
      address: "0x82aF49447D8a07e3bd95BD0d56f35241523fBab1",
      name: "Wrapped Ether",
      symbol: "WETH",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2/logo.png"
    },
    {
      chainId: 42161,
      address: "0x912CE59144191C1204E64559FE8253a0e49E6548",
      name: "Arbitrum",
      symbol: "ARB",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0x912CE59144191C1204E64559FE8253a0e49E6548.png"
    },
    {
      chainId: 42161,
      address: "0xd5046B976188EB40f6DE40fB527F89c05b323385",
      name: "HERMES",
      symbol: "HERMES",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0xd5046B976188EB40f6DE40fB527F89c05b323385.png"
    },
    {
      chainId: 42161,
      address: "0x4e61743278Bc95cF874A5416A9E6F9547C413DE8",
      name: "MAIA",
      symbol: "MAIA",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0x4e61743278Bc95cF874A5416A9E6F9547C413DE8.png"
    },
    {
      chainId: 42161,
      address: "0xa5edbdd9646f8dff606d7448e414884c7d905dca",
      name: "ARA Token",
      symbol: "ARA",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0xa5edbdd9646f8dff606d7448e414884c7d905dca.png"
    },
    {
      chainId: 42161,
      address: "0x47c227c9f05189b97814ce96284129cd0c62d211",
      name: "GameFi",
      symbol: "GAMEFI",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0x47c227c9f05189b97814ce96284129cd0c62d211.png"
    },
    {
      chainId: 42161,
      address: "0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f",
      name: "Wrapped BTC",
      symbol: "WBTC",
      decimals: 8,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f.png"
    },
    {
      chainId: 42161,
      address: "0x539bdE0d7Dbd336b79148AA742883198BBF60342",
      name: "Magic",
      symbol: "MAGIC",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0x539bdE0d7Dbd336b79148AA742883198BBF60342.png"
    },
    {
      chainId: 42161,
      address: "0x32Eb7902D4134bf98A28b963D26de779AF92A212",
      name: "Dopex Governance Token",
      symbol: "DPX",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0x32Eb7902D4134bf98A28b963D26de779AF92A212.png"
    },
    {
      chainId: 42161,
      address: "0x6C2C06790b3E3E3c38e12Ee22F8183b37a13EE55",
      name: "Dopex Rebate Token",
      symbol: "RDPX",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0x6C2C06790b3E3E3c38e12Ee22F8183b37a13EE55.png"
    },
    {
      chainId: 42161,
      address: "0x5979D7b546E38E414F7E9822514be443A4800529",
      name: "Wrapped stETH",
      symbol: "wstETH",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0x5979D7b546E38E414F7E9822514be443A4800529.png"
    },
    {
      chainId: 42161,
      address: "0xf97f4df75117a78c1A5a0DBb814Af92458539FB4",
      name: "ChainLink Token",
      symbol: "LINK",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0xf97f4df75117a78c1A5a0DBb814Af92458539FB4.png"
    },
    {
      chainId: 42161,
      address: "0xfc5A1A6EB076a2C7aD06eD22C90d7E710E35ad0a",
      name: "GMX",
      symbol: "GMX",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0xfc5A1A6EB076a2C7aD06eD22C90d7E710E35ad0a.png"
    },
    {
      chainId: 42161,
      address: "0x2Ac2B254Bc18cD4999f64773a966E4f4869c34Ee",
      name: "Radiant",
      symbol: "RDNT",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0x2Ac2B254Bc18cD4999f64773a966E4f4869c34Ee.png"
    },
    {
      chainId: 42161,
      address: "0xFa7F8980b0f1E64A2062791cc3b0871572f1F7f0",
      name: "Uniswap",
      symbol: "UNI",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/arbitrum/0xFa7F8980b0f1E64A2062791cc3b0871572f1F7f0.png"
    },
    // Base Tokens
    {
      chainId: 8453,
      address: "0x4200000000000000000000000000000000000006",
      name: "Wrapped Ether",
      symbol: "WETH",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/ethereum/assets/0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2/logo.png"
    },
    {
      chainId: 8453,
      address: "0x7B1695D2c3E76F1F8608638272eC0e8f3578bF0d",
      name: "Toshi",
      symbol: "TOSHI",
      decimals: 18,
      logoURI: "https://raw.githubusercontent.com/Maia-DAO/token-list-v2/main/logos/base/0x7B1695D2c3E76F1F8608638272eC0e8f3578bF0d.png"
    }
  ]
}; 