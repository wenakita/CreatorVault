import { BrowserRouter, Routes, Route } from "react-router-dom";
import Traditional from "./components/dashboard/Traditional";
import {
  DynamicContextProvider,
  useIsLoggedIn,
} from "@dynamic-labs/sdk-react-core";
import { EthereumWalletConnectors } from "@dynamic-labs/ethereum";
import { base, arbitrum } from "viem/chains";
import { Provider } from "react-redux";
import store from "./store/index";
import View from "./components/view/View";
import Deposit from "./components/Deposit/Deposit";
import HomePage from "./components/dashboard/Homepage";
import Agent from "./components/dashboard/Agent";
function App() {
  const dynamicSettings = {
    environmentId: "3f6134d4-3d91-4d31-879e-aa828e2e3b3f",
    walletConnectors: [EthereumWalletConnectors],
    enableEnsLookup: true,
    evmNetworks: [
      {
        chainId: base.id,
        chainName: "Base",
        networkId: base.id,
        nativeCurrency: {
          name: "Ethereum",
          symbol: "ETH",
          decimals: 18,
        },
        rpcUrls: [base.rpcUrls.default.http[0]],
        blockExplorerUrls: [base.blockExplorers.default.url],
      },
      {
        chainId: arbitrum.id,
        chainName: "Arbitrum",
        networkId: arbitrum.id,
        nativeCurrency: {
          name: "Ethereum",
          symbol: "ETH",
          decimals: 18,
        },
        rpcUrls: [arbitrum.rpcUrls.default.http[0]],
        blockExplorerUrls: [arbitrum.blockExplorers.default.url],
      },
    ],
    defaultNetwork: base.id,
    cssOverride: {
      colors: {
        primary: "#3B82F6",
        secondary: "#1D4ED8",
      },
    },
    siweStatement: `Welcome to Cerberus by GODDOG. Signing is the only way we can truly know that you are the owner of the wallet you are connecting. Signing is a safe, gas-less transaction that does not in any way give permission to perform any transactions with your wallet.`,
  };

  return (
    <Provider store={store}>
      <DynamicContextProvider settings={dynamicSettings}>
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/agent" element={<Agent />} />
            <Route path="/traditional" element={<Traditional />} />
            <Route path="/view" element={<View />} />
            <Route path={`/vault/:vaultaddress`} element={<Deposit />} />
            <Route path="*" element={<div>not found</div>} />
          </Routes>
        </BrowserRouter>
      </DynamicContextProvider>
    </Provider>
  );
}

export default App;
